SELECT email FROM public.customer WHERE active=0;
